cordova.define('cordova/plugin_list', function (require, exports, module) {

  module.exports = [
    {
      "id": "cordova-plugin-console.console",
      "file": "plugins/cordova-plugin-console/www/console-via-logger.js",
      "pluginId": "cordova-plugin-console",
      "clobbers": [
        "cordova.console",
        "window.console"
      ]
    },
    {
      "id": "cordova-plugin-console.logger",
      "file": "plugins/cordova-plugin-console/www/logger.js",
      "pluginId": "cordova-plugin-console",
      "clobbers": [
        "cordova.logger",
        "window.logger"
      ]
    },
    {
      "id": "cordova-plugin-device.device",
      "file": "plugins/cordova-plugin-device/www/device.js",
      "pluginId": "cordova-plugin-device",
      "clobbers": [
        "cordova.device",
        "window.device"
      ]
    },
    {
      "id": "cordova-plugin-splashscreen.SplashScreen",
      "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
      "pluginId": "cordova-plugin-splashscreen",
      "clobbers": [
        "cordova.navigator.splashscreen",
        "window.navigator.splashscreen"
      ]
    },
    {
      "id": "ionic-plugin-keyboard.keyboard",
      "file": "plugins/ionic-plugin-keyboard/www/ios/keyboard.js",
      "pluginId": "ionic-plugin-keyboard",
      "clobbers": [
        "cordova.Keyboard",
        "window.Keyboard"
      ],
      "runs": true
    },
    {
      "id": "cordova-plugin-powwow.powwow",
      "file": "plugins/cordova-plugin-powwow/www/powwow.js",
      "pluginId": "cordova-plugin-powwow",
      "clobbers": [
        "cordova.PowwowPlugin",
        "window.PowwowPlugin"
      ]
    },
    {
      "id": "cordova-plugin-cookiesync.cookiesync",
      "file": "plugins/cordova-plugin-cookiesync/www/cookies.js",
      "pluginId": "cordova-plugin-cookiesync",
      "clobbers": [
        "cordova.CookieSync",
        "window.CookieSync"
      ]
    },
    {
      "id": "net.yoik.cordova.plugins.screenorientation.screenorientation",
      "file": "plugins/net.yoik.cordova.plugins.screenorientation/www/screenorientation.js",
      "clobbers": [
        "cordova.screenorientation.screenorientation",
        "window.screenorientation.screenorientation"
      ]
    },
    {
      "id": "net.yoik.cordova.plugins.screenorientation.screenorientation.ios",
      "file": "plugins/net.yoik.cordova.plugins.screenorientation/www/screenorientation.ios.js",
      "merges": [
        "cordova.screenorientation.screenorientation",
        "window.screenorientation.screenorientation"
      ]
    },
    {
      "id": "org.apache.cordova.camera.Camera",
      "file": "plugins/org.apache.cordova.camera/www/CameraConstants.js",
      "clobbers": [
        "cordova.Camera",
        "window.Camera"
      ]
    },
    {
      "id": "org.apache.cordova.camera.CameraPopoverOptions",
      "file": "plugins/org.apache.cordova.camera/www/CameraPopoverOptions.js",
      "clobbers": [
        "cordova.CameraPopoverOptions",
        "window.CameraPopoverOptions"
      ]
    },
    {
      "id": "org.apache.cordova.camera.camera",
      "file": "plugins/org.apache.cordova.camera/www/Camera.js",
      "clobbers": [
        "cordova.navigator.camera",
        "window.navigator.camera"
      ]
    },
    {
      "id": "org.apache.cordova.camera.CameraPopoverHandle",
      "file": "plugins/org.apache.cordova.camera/www/ios/CameraPopoverHandle.js",
      "clobbers": [
        "cordova.CameraPopoverHandle",
        "window.CameraPopoverHandle"
      ]
    },
    {
      "id": "cordova-plugin-file.DirectoryEntry",
      "file": "plugins/cordova-plugin-file/www/DirectoryEntry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.DirectoryEntry",
        "window.DirectoryEntry"
      ]
    },
    {
      "id": "cordova-plugin-file.DirectoryReader",
      "file": "plugins/cordova-plugin-file/www/DirectoryReader.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.DirectoryReader",
        "window.DirectoryReader"
      ]
    },
    {
      "id": "cordova-plugin-file.Entry",
      "file": "plugins/cordova-plugin-file/www/Entry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Entry",
        "window.Entry"
      ]
    },
    {
      "id": "cordova-plugin-file.File",
      "file": "plugins/cordova-plugin-file/www/File.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.File",
        "window.File"
      ]
    },
    {
      "id": "cordova-plugin-file.FileEntry",
      "file": "plugins/cordova-plugin-file/www/FileEntry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileEntry",
        "window.FileEntry"
      ]
    },
    {
      "id": "cordova-plugin-file.FileError",
      "file": "plugins/cordova-plugin-file/www/FileError.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileError",
        "window.FileError",
      ]
    },
    {
      "id": "cordova-plugin-file.FileReader",
      "file": "plugins/cordova-plugin-file/www/FileReader.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileReader",
        "window.FileReader"
      ]
    },
    {
      "id": "cordova-plugin-file.FileSystem",
      "file": "plugins/cordova-plugin-file/www/FileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileSystem",
        "window.FileSystem"
      ]
    },
    {
      "id": "cordova-plugin-file.FileUploadOptions",
      "file": "plugins/cordova-plugin-file/www/FileUploadOptions.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileUploadOptions",
        "window.FileUploadOptions"
      ]
    },
    {
      "id": "cordova-plugin-file.FileUploadResult",
      "file": "plugins/cordova-plugin-file/www/FileUploadResult.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileUploadResult",
        "window.FileUploadResult"
      ]
    },
    {
      "id": "cordova-plugin-file.FileWriter",
      "file": "plugins/cordova-plugin-file/www/FileWriter.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileWriter",
        "window.FileWriter"
      ]
    },
    {
      "id": "cordova-plugin-file.Flags",
      "file": "plugins/cordova-plugin-file/www/Flags.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Flags",
        "window.Flags"
      ]
    },
    {
      "id": "cordova-plugin-file.LocalFileSystem",
      "file": "plugins/cordova-plugin-file/www/LocalFileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.LocalFileSystem",
        "window.LocalFileSystem"
      ],
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-file.Metadata",
      "file": "plugins/cordova-plugin-file/www/Metadata.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Metadata",
        "window.Metadata"
      ]
    },
    {
      "id": "cordova-plugin-file.ProgressEvent",
      "file": "plugins/cordova-plugin-file/www/ProgressEvent.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.ProgressEvent",
        "window.ProgressEvent"
      ]
    },
    {
      "id": "cordova-plugin-file.fileSystems",
      "file": "plugins/cordova-plugin-file/www/fileSystems.js",
      "pluginId": "cordova-plugin-file"
    },
    {
      "id": "cordova-plugin-file.requestFileSystem",
      "file": "plugins/cordova-plugin-file/www/requestFileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.requestFileSystem",
        "window.requestFileSystem"
      ]
    },
    {
      "id": "cordova-plugin-file.resolveLocalFileSystemURI",
      "file": "plugins/cordova-plugin-file/www/resolveLocalFileSystemURI.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-file.iosFileSystem",
      "file": "plugins/cordova-plugin-file/www/ios/FileSystem.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "cordova.FileSystem",
      ]
    },
    {
      "id": "cordova-plugin-file.fileSystems-roots",
      "file": "plugins/cordova-plugin-file/www/fileSystems-roots.js",
      "pluginId": "cordova-plugin-file",
      "runs": true
    },
    {
      "id": "cordova-plugin-file.fileSystemPaths",
      "file": "plugins/cordova-plugin-file/www/fileSystemPaths.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "cordova"
      ],
      "runs": true
    },
    {
      "id": "cordova-plugin-file-transfer.FileTransferError",
      "file": "plugins/cordova-plugin-file-transfer/www/FileTransferError.js",
      "pluginId": "cordova-plugin-file-transfer",
      "clobbers": [
        "cordova.FileTransferError",
        "window.FileTransferError"
      ]
    },
    {
      "id": "cordova-plugin-file-transfer.FileTransfer",
      "file": "plugins/cordova-plugin-file-transfer/www/FileTransfer.js",
      "pluginId": "cordova-plugin-file-transfer",
      "clobbers": [
        "cordova.FileTransfer",
        "window.FileTransfer"
      ]
    },
    {
      "id": "cordova-plugin-inappbrowser.inappbrowser",
      "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
      "pluginId": "cordova-plugin-inappbrowser",
      "clobbers": [
        "cordova.InAppBrowser.open",
        "window.InAppBrowser.open"
      ]
    },
    {
      "id": "de.appplant.cordova.plugin.local-notification.LocalNotification",
      "file": "plugins/de.appplant.cordova.plugin.local-notification/www/local-notification.js",
      "pluginId": "de.appplant.cordova.plugin.local-notification",
      "clobbers": [
        "cordova.notification.local",
        "window.notification.local"
      ]
    },
    {
      "id": "de.appplant.cordova.plugin.local-notification.LocalNotification.Core",
      "file": "plugins/de.appplant.cordova.plugin.local-notification/www/local-notification-core.js",
      "pluginId": "de.appplant.cordova.plugin.local-notification",
      "clobbers": [
        "cordova.notification.local.core",
        "window.notification.local.core"
      ]
    },
    {
      "id": "de.appplant.cordova.plugin.local-notification.LocalNotification.Util",
      "file": "plugins/de.appplant.cordova.plugin.local-notification/www/local-notification-util.js",
      "pluginId": "de.appplant.cordova.plugin.local-notification",
      "merges": [
        "cordova.notification.local.core"
      ]
    }, {
      "id": "cordova-plugin-wkwebview-engine.ios-wkwebview-exec",
      "file": "plugins/cordova-plugin-wkwebview-engine/src/www/ios/ios-wkwebview-exec.js",
      "pluginId": "cordova-plugin-wkwebview-engine",
      "clobbers": [
        "cordova.exec"
      ]
    },
    {
      "id": "cordova-plugin-secure-storage.SecureStorage",
      "file": "plugins/cordova-plugin-secure-storage/www/securestorage.js",
      "pluginId": "cordova-plugin-secure-storage",
      "clobbers": [
        "cordova.SecureStorage",
        "window.SecureStorage"
      ]
    },
    {
      "id": "cordova-plugin-secure-storage.sjcl_ss",
      "file": "plugins/cordova-plugin-secure-storage/www/sjcl_ss.js",
      "pluginId": "cordova-plugin-secure-storage",
      "runs": true
    },
    {
      "id": "phonegap-plugin-barcodescanner.BarcodeScanner",
      "file": "plugins/phonegap-plugin-barcodescanner/www/barcodescanner.js",
      "pluginId": "phonegap-plugin-barcodescanner",
      "clobbers": [
        "cordova.barcodeScanner",
        "window.barcodeScanner"
      ]
    },
    {
      "id": "cordova-plugin-lz-PdfViewer.PdfViewer",
      "file": "plugins/cordova-plugin-lz-PdfViewer/www/PdfViewer.js",
      "pluginId": "cordova-plugin-lz-PdfViewer",
      "clobbers": [
        "cordova.PdfViewer",
        "window.PdfViewer"
      ]
    },
    {
      "id": "cordova-plugin-keychain-touch-id.TouchID",
      "file": "plugins/cordova-plugin-keychain-touch-id/www/touchid.js",
      "pluginId": "cordova-plugin-keychain-touch-id",
      "clobbers": [
        "cordova.touchid",
        "window.touchid",
      ]
    },
    {
      "id": "cordova-plugin-screen-orientation.screenorientation",
      "file": "plugins/cordova-plugin-screen-orientation/www/screenorientation.js",
      "pluginId": "cordova-plugin-screen-orientation",
      "clobbers": [
        "cordova.screenorientation",
        "window.screenorientation"
      ]
    },
    {
      "id": "phonegap-plugin-push.PushNotification",
      "file": "plugins/phonegap-plugin-push/www/push.js",
      "pluginId": "phonegap-plugin-push",
      "clobbers": [
        "cordova.PushNotification",
        "window.PushNotification"
      ]
    }

  ];
  module.exports.metadata =
// TOP OF METADATA
    {
      "cordova-plugin-console": "1.0.5",
      "cordova-plugin-device": "1.1.4",
      "cordova-plugin-splashscreen": "4.0.3",
      "cordova-plugin-whitelist": "1.3.1",
      "ionic-plugin-keyboard": "2.2.1"
    };
// BOTTOM OF METADATA
});
