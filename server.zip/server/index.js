// Load the SmartUX session runtime.
let session = require('smartux-connect');

// API Connectors

// Web Connectors

session.start();
