cordova.define('cordova/plugin_list', function (require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-device.device",
      "file": "plugins/cordova-plugin-device/www/device.js",
      "pluginId": "cordova-plugin-device",
      "clobbers": [
        "cordova.device",
        "window.device"
      ]
    },
    {
      "id": "cordova-plugin-splashscreen.SplashScreen",
      "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
      "pluginId": "cordova-plugin-splashscreen",
      "clobbers": [
        "cordova.navigator.splashscreen",
        "window.navigator.splashscreen"
      ]
    },
    {
      "id": "cordova-plugin-statusbar.statusbar",
      "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
      "pluginId": "cordova-plugin-statusbar",
      "clobbers": [
        "cordova.StatusBar",
        "window.StatusBar"
      ]
    },
    {
      "id": "ionic-plugin-keyboard.keyboard",
      "file": "plugins/ionic-plugin-keyboard/www/android/keyboard.js",
      "pluginId": "ionic-plugin-keyboard",
      "clobbers": [
        "cordova.Keyboard",
        "window.Keyboard"
      ],
      "runs": true
    },
    {
      "id": "cordova-plugin-powwow.powwow",
      "file": "plugins/cordova-plugin-powwow/www/powwow.js",
      "pluginId": "cordova-plugin-powwow",
      "clobbers": [
        "cordova.PowwowPlugin",
        "window.PowwowPlugin"
      ]
    },
    {
      "id": "org.apache.cordova.camera.Camera",
      "file": "plugins/org.apache.cordova.camera/www/CameraConstants.js",
      "clobbers": [
        "cordova.Camera",
        "window.Camera"
      ]
    },
    {
      "id": "org.apache.cordova.camera.CameraPopoverOptions",
      "file": "plugins/org.apache.cordova.camera/www/CameraPopoverOptions.js",
      "clobbers": [
        "cordova.CameraPopoverOptions",
        "window.CameraPopoverOptions"
      ]
    },
    {
      "id": "org.apache.cordova.camera.camera",
      "file": "plugins/org.apache.cordova.camera/www/Camera.js",
      "clobbers": [
        "cordova.navigator.camera",
        "window.navigator.camera"
      ]
    },
    {
      "id": "org.apache.cordova.camera.CameraPopoverHandle",
      "file": "plugins/org.apache.cordova.camera/www/ios/CameraPopoverHandle.js",
      "clobbers": [
        "cordova.CameraPopoverHandle",
        "window.CameraPopoverHandle"
      ]
    },
    {
      "id": "cordova-plugin-file-transfer.FileTransferError",
      "file": "plugins/cordova-plugin-file-transfer/www/FileTransferError.js",
      "pluginId": "cordova-plugin-file-transfer",
      "clobbers": [
        "cordova.FileTransferError",
        "window.FileTransferError"
      ]
    },
    {
      "id": "cordova-plugin-file-transfer.FileTransfer",
      "file": "plugins/cordova-plugin-file-transfer/www/FileTransfer.js",
      "pluginId": "cordova-plugin-file-transfer",
      "clobbers": [
        "cordova.FileTransfer",
        "window.FileTransfer"
      ]
    },
    {
      "id": "cordova-plugin-file.DirectoryEntry",
      "file": "plugins/cordova-plugin-file/www/DirectoryEntry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.DirectoryEntry",
        "window.DirectoryEntry"
      ]
    },
    {
      "id": "cordova-plugin-file.DirectoryReader",
      "file": "plugins/cordova-plugin-file/www/DirectoryReader.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.DirectoryReader",
        "window.DirectoryReader"
      ]
    },
    {
      "id": "cordova-plugin-file.Entry",
      "file": "plugins/cordova-plugin-file/www/Entry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Entry",
        "window.Entry"
      ]
    },
    {
      "id": "cordova-plugin-file.File",
      "file": "plugins/cordova-plugin-file/www/File.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.File",
        "window.File"
      ]
    },
    {
      "id": "cordova-plugin-file.FileEntry",
      "file": "plugins/cordova-plugin-file/www/FileEntry.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileEntry",
        "window.FileEntry"
      ]
    },
    {
      "id": "cordova-plugin-file.FileError",
      "file": "plugins/cordova-plugin-file/www/FileError.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileError",
        "window.FileError"
      ]
    },
    {
      "id": "cordova-plugin-file.FileReader",
      "file": "plugins/cordova-plugin-file/www/FileReader.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileReader",
        "window.FileReader"
      ]
    },
    {
      "id": "cordova-plugin-file.FileSystem",
      "file": "plugins/cordova-plugin-file/www/FileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileSystem",
        "window.FileSystem",
      ]
    },
    {
      "id": "cordova-plugin-file.FileUploadOptions",
      "file": "plugins/cordova-plugin-file/www/FileUploadOptions.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileUploadOptions",
        "window.FileUploadOptions"
      ]
    },
    {
      "id": "cordova-plugin-file.FileUploadResult",
      "file": "plugins/cordova-plugin-file/www/FileUploadResult.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileUploadResult",
        "window.FileUploadResult"
      ]
    },
    {
      "id": "cordova-plugin-file.FileWriter",
      "file": "plugins/cordova-plugin-file/www/FileWriter.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.FileWriter",
        "window.FileWriter"
      ]
    },
    {
      "id": "cordova-plugin-file.Flags",
      "file": "plugins/cordova-plugin-file/www/Flags.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Flags",
        "window.Flags"
      ]
    },
    {
      "id": "cordova-plugin-file.LocalFileSystem",
      "file": "plugins/cordova-plugin-file/www/LocalFileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.LocalFileSystem",
        "window.LocalFileSystem"
      ],
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-file.Metadata",
      "file": "plugins/cordova-plugin-file/www/Metadata.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.Metadata",
        "window.Metadata"
      ]
    },
    {
      "id": "cordova-plugin-file.ProgressEvent",
      "file": "plugins/cordova-plugin-file/www/ProgressEvent.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.ProgressEvent",
        "window.ProgressEvent"
      ]
    },
    {
      "id": "cordova-plugin-file.fileSystems",
      "file": "plugins/cordova-plugin-file/www/fileSystems.js",
      "pluginId": "cordova-plugin-file"
    },
    {
      "id": "cordova-plugin-file.requestFileSystem",
      "file": "plugins/cordova-plugin-file/www/requestFileSystem.js",
      "pluginId": "cordova-plugin-file",
      "clobbers": [
        "cordova.requestFileSystem",
        "window.requestFileSystem"
      ]
    },
    {
      "id": "cordova-plugin-file.resolveLocalFileSystemURI",
      "file": "plugins/cordova-plugin-file/www/resolveLocalFileSystemURI.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-file.androidFileSystem",
      "file": "plugins/cordova-plugin-file/www/android/FileSystem.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "FileSystem"
      ]
    },
    {
      "id": "cordova-plugin-file.fileSystems-roots",
      "file": "plugins/cordova-plugin-file/www/fileSystems-roots.js",
      "pluginId": "cordova-plugin-file",
      "runs": true
    },
    {
      "id": "cordova-plugin-file.fileSystemPaths",
      "file": "plugins/cordova-plugin-file/www/fileSystemPaths.js",
      "pluginId": "cordova-plugin-file",
      "merges": [
        "cordova"
      ],
      "runs": true
    },
    {
      "id": "cordova-plugin-locationservices.Coordinates",
      "file": "plugins/cordova-plugin-locationservices/www/Coordinates.js",
      "clobbers": [
        "cordova.locationServices.Coordinates",
        "window.locationServices.Coordinates"
      ]
    },
    {
      "id": "cordova-plugin-locationservices.PositionError",
      "file": "plugins/cordova-plugin-locationservices/www/PositionError.js",
      "clobbers": [
        "cordova.locationServices.PositionError",
        "window.locationServices.PositionError"
      ]
    },
    {
      "id": "cordova-plugin-locationservices.Position",
      "file": "plugins/cordova-plugin-locationservices/www/Position.js",
      "clobbers": [
        "cordovalocationServices.PositionError",
        "window.locationServices.PositionError"
      ]
    },
    {
      "id": "cordova-plugin-locationservices.LocationServices",
      "file": "plugins/cordova-plugin-locationservices/www/LocationServices.js",
      "clobbers": [
        "cordova.locationServices.geolocation",
        "window.locationServices.geolocation"
      ]
    },
    {
      "id": "cordova-plugin-inappbrowser.inappbrowser",
      "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
      "clobbers": [
        "cordova.InAppBrowser.open",
        "window.InAppBrowser.open"
      ]
    },
    {
      "id": "cordova-bluebird-api.BluebirdBarcodeScanner",
      "file": "plugins/cordova-bluebird-api/www/barcodescanner.js",
      "clobbers": [
        "cordova.bluebirdBarcodeScanner",
        "window.bluebirdBarcodeScanner"
      ]
    },
    {
      "id": "cordova-delta.OcrScanner",
      "file": "plugins/cordova-delta/www/ocrscanner.js",
      "clobbers": [
        "cordova.deltaOcrScanner",
        "window.deltaOcrScanner"
      ]
    },
    {
      "id": "cordova-plugin-network-information.network",
      "file": "plugins/cordova-plugin-network-information/www/network.js",
      "pluginId": "cordova-plugin-network-information",
      "clobbers": [
        "cordova.navigator.network.connection",
        "window.navigator.network.connection"
      ]
    },
    {
      "id": "cordova-plugin-network-information.Connection",
      "file": "plugins/cordova-plugin-network-information/www/Connection.js",
      "pluginId": "cordova-plugin-network-information",
      "clobbers": [
        "cordova.Connection",
        "window.Connection"
      ]
    },
    {
      "id": "cordova-plugin-secure-storage.SecureStorage",
      "file": "plugins/cordova-plugin-secure-storage/www/securestorage.js",
      "pluginId": "cordova-plugin-secure-storage",
      "clobbers": [
        "cordova.SecureStorage",
        "window.SecureStorage"
      ]
    },
    {
      "id": "cordova-plugin-secure-storage.sjcl_ss",
      "file": "plugins/cordova-plugin-secure-storage/www/sjcl_ss.js",
      "pluginId": "cordova-plugin-secure-storage",
      "runs": true
    },
    {
      "id": "es6-promise-plugin.Promise",
      "file": "plugins/es6-promise-plugin/www/promise.js",
      "pluginId": "es6-promise-plugin",
      "runs": true
    },
    {
      "id": "cordova-plugin-screen-orientation.screenorientation",
      "file": "plugins/cordova-plugin-screen-orientation/www/screenorientation.js",
      "pluginId": "cordova-plugin-screen-orientation",
      "clobbers": [
        "cordova.screenorientation",
        "window.screenorientation"
      ]
    },
    {
      "id": "cordova-plugin-pdfviewer.PdfViewer",
      "file": "plugins/cordova-plugin-pdfviewer/www/PdfViewer.js",
      "pluginId": "cordova-plugin-pdfviewer.PdfViewer",
      "clobbers": [
        "cordova.PdfViewer",
        "window.PdfViewer"
      ]
    },
    {
      "id": "cordova-plugin-cookiesync.cookiesync",
      "file": "plugins/cordova-plugin-cookiesync/www/cookies.js",
      "pluginId": "cordova-plugin-cookiesync",
      "clobbers": [
        "cordova.CookieSync",
        "window.CookieSync"
      ]
    },
    {
      "id": "phonegap-plugin-barcodescanner.BarcodeScanner",
      "file": "plugins/phonegap-plugin-barcodescanner/www/barcodescanner.js",
      "pluginId": "phonegap-plugin-barcodescanner",
      "clobbers": [
        "cordova.barcodeScanner",
        "window.barcodeScanner"
      ]
    },
    {
      "id": "phonegap-plugin-push.PushNotification",
      "file": "plugins/phonegap-plugin-push/www/push.js",
      "pluginId": "phonegap-plugin-push",
      "clobbers": [
        "cordova.PushNotification",
        "window.PushNotification"
      ]
    }

  ];
  module.exports.metadata =
// TOP OF METADATA
    {
      "cordova-plugin-console": "1.0.5",
      "cordova-plugin-device": "1.1.4",
      "cordova-plugin-splashscreen": "4.0.3",
      "cordova-plugin-statusbar": "2.2.2",
      "cordova-plugin-whitelist": "1.3.1",
      "ionic-plugin-keyboard": "2.2.1",
      "cordova-plugin-network-information": "1.3.3",
      "cordova-plugin-secure-storage": "2.6.8",
      "cordova-plugin-compat": "1.0.0",
      "es6-promise-plugin": "4.1.0",
      "cordova-plugin-screen-orientation": "2.0.1",
      "cordova-plugin-file": "4.0.0",
      "cordova-plugin-file-transfer": "1.6.3",
      "cordova-plugin-camera": "2.4.1"
    };
// BOTTOM OF METADATA
});
